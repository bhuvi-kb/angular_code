import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Params, ActivatedRoute } from '@angular/router';
import { KeechService } from '../services/keech.service';
import { ProfileupdateService } from '../services/profileupdate.service';
import { Keech } from '../models/keech';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { BASE_URL } from '../shared/constants';
import { UserfollowersComponent } from '../userfollowers/userfollowers.component'
import { UserfollowingComponent } from '../userfollowing/userfollowing.component';
import { LikeshareService } from '../services/likeshare.service';


@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {

  keechData=[];
  fullname=''
  uname = 'username';
  userid;
  following;
  numfollowing;
  numfollowers;
  keechText={keechBody:''};
  postedKeech: Keech;
  token = localStorage.getItem('token');
  baseUrl=BASE_URL;
  avatarurl;
 
  //uname = localStorage.getItem('ssid');
 
  disablePostText=false;

  constructor(private route: ActivatedRoute,
    private location: Location,
    private keechService: KeechService,
    private profileService: ProfileupdateService,
    private followersDialog: MatDialog,
    private likesShareService: LikeshareService) { }

  ngOnInit(): void {
    const id=this.route.snapshot.params['id']
    

    this.profileService.getUserProfile(id).subscribe(
      res=> {
        
        this.fullname=res.firstname + ' ' + res.lastname;
        this.uname=res.username;
        this.userid=res.userid  
        this.following=res.alreadyFollowing;
        this.numfollowing=res.numfollowing;
        this.numfollowers=res.numfollowers;
        this.avatarurl=this.baseUrl+res.avatarurl;
      },
      err => console.log(err)
    );

    this.keechService.getKeeches(id).subscribe(
      response => {
        this.keechData = response;
        //this.uname = this.keechData[0].author
      },
      err => { console.log(err)}
    )
  }


  addFollowing() {
    
    this.profileService.addFollowing(this.userid).subscribe(
      res=>{
      
        this.following=true;
      }
    )
  }


  unfollow() {
   
    this.profileService.unfollow(this.userid).subscribe(
      res=>{
        
        this.following=false;
      }
    )
  }

  toggleFollow(){
    if(!this.following) {
      this.addFollowing()
    }
    else {
      this.unfollow();
    }
  }

  postKeech(keech) {
   
    this.disablePostText=true;
    this.keechService.postKeech(keech).subscribe(
      (res)=> {
       
        this.postedKeech=res;
       
        this.keechText.keechBody='';
        this.keechData.unshift(this.postedKeech);
        this.disablePostText=false;
        
      },
      (err)=> {
        console.log(err);
        this.disablePostText=false;
      }
    )
  }


  openFollowers(userid){
    let dialogConfig= new MatDialogConfig();
    dialogConfig.width = '500px';
    dialogConfig.height = '500px';

    dialogConfig.data = {
      userid: userid
    }

    this.followersDialog.open(UserfollowersComponent, dialogConfig)
  }

  openFollowing(userid){
    let dialogConfig= new MatDialogConfig();
    dialogConfig.width = '500px';
    dialogConfig.height = '500px';

    dialogConfig.data = {
      userid: userid
    }

    this.followersDialog.open(UserfollowingComponent, dialogConfig)
  }



  
  toggleLikeKeech(keech){

    if (!keech.isLiked) {

      this.likesShareService.addLike(keech._id).subscribe(
        res => {
          
          keech.isLiked = !keech.isLiked
          keech.likes ++
        },
        err => {
          console.log(err)
        }
      );


    }
    else {

      this.likesShareService.removeLike(keech._id).subscribe(
        res => {
          
          keech.isLiked = !keech.isLiked
          keech.likes --
        },
        err => console.log(err)
      );
 

    }


  }


  toggleShareKeech(keech){

    if (!keech.isShared) {

      this.likesShareService.addShare(keech._id).subscribe(
        res => {
         
          keech.isShared = !keech.isShared
          keech.shares ++
        },
        err => console.log(err)
      );


    }
    else {

      this.likesShareService.removeShare(keech._id).subscribe(
        res => {
          
          keech.isShared = !keech.isShared
          keech.shares --
        },
        err => console.log(err)
      );
 

    }


  }
  
}
