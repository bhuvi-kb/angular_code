import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth.guard';
import { UserdetailComponent } from './userdetail/userdetail.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { SearchComponent } from './search/search.component';
import { KeechdetailComponent } from './keechdetail/keechdetail.component';
import { NotificationsComponent } from './notifications/notifications.component';


const routes: Routes = [
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard]},
  { path: 'user/:id', component: UserdetailComponent},
  { path: 'updateprofile', component: UpdateprofileComponent, canActivate: [AuthGuard]},
  { path: '', redirectTo: '/home', pathMatch:'full'},
  { path: 'post/:id', component: KeechdetailComponent},
  { path: 'search', component:SearchComponent},
  { path:'notifications', component:NotificationsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
