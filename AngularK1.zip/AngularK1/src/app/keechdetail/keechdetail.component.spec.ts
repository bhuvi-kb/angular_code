import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeechdetailComponent } from './keechdetail.component';

describe('KeechdetailComponent', () => {
  let component: KeechdetailComponent;
  let fixture: ComponentFixture<KeechdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeechdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeechdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
