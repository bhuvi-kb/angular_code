import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { KeechdetailService } from '../services/keechdetail.service';
import { BASE_URL } from '../shared/constants';
import { KeechService } from '../services/keech.service';
import { LikeshareService } from '../services/likeshare.service';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { LikedusersComponent } from '../likedusers/likedusers.component';
import { SharedusersComponent } from '../sharedusers/sharedusers.component';

@Component({
  selector: 'app-keechdetail',
  templateUrl: './keechdetail.component.html',
  styleUrls: ['./keechdetail.component.css']
})
export class KeechdetailComponent implements OnInit {

  keech;
  baseUrl=BASE_URL;
  keechText={keechBody:'', inReplyTo:''};
  reply=false;
  disablePostText=false;
  replies;

  constructor(private route: ActivatedRoute, 
    private keechDetailsService: KeechdetailService,
    private keechService: KeechService,
    private likesShareService: LikeshareService,
    private likedSharedUsersDialog: MatDialog) { }
  
  ngOnInit(): void {
    const id=this.route.snapshot.params['id'];
    
    this.keechDetailsService.getPostDetail(id).subscribe(
      res=> {
        //console.log(res);
        this.keech = res},
      err => { console.log(err)}
    )

    this.keechDetailsService.getReplies(id).subscribe(
      res=> {
        //console.log(res);
        this.replies=res},
      err=> console.log(err)
    )
    
  }


  postReply(keechBody, inReplyTo) {
    this.disablePostText=true;
    let k = {keechBody, inReplyTo};
    //console.log(k);
    this.keechService.postKeech(k).subscribe(
      res=>{ 
        this.replies.unshift(res);
        //console.log(res);
        this.disablePostText=false;
        this.reply=false;
        this.keechText={keechBody:'', inReplyTo:''};
        
      },
      err=> console.log(err)
    )
  }

 
 
  toggleLikeKeech(keech){

    if (!keech.isLiked) {

      this.likesShareService.addLike(keech._id).subscribe(
        res => {
          //console.log(res);
          keech.isLiked = !keech.isLiked
          keech.likes ++
        },
        err => {
          console.log(err)
        }
      );


    }
    else {

      this.likesShareService.removeLike(keech._id).subscribe(
        res => {
          //console.log(res);
          keech.isLiked = !keech.isLiked
          keech.likes --
        },
        err => console.log(err)
      );
 

    }


  }


  toggleShareKeech(keech){

    if (!keech.isShared) {

      this.likesShareService.addShare(keech._id).subscribe(
        res => {
         // console.log(res);
          keech.isShared = !keech.isShared
          keech.shares ++
        },
        err => console.log(err)
      );


    }
    else {

      this.likesShareService.removeShare(keech._id).subscribe(
        res => {
          //console.log(res);
          keech.isShared = !keech.isShared
          keech.shares --
        },
        err => console.log(err)
      );
 

    }


  }


  openLikedUsers(keechId){
    let dialogConfig= new MatDialogConfig();
    dialogConfig.width = '500px';
    dialogConfig.height = '500px';

    dialogConfig.data = {
      keechId: keechId
    }

    this.likedSharedUsersDialog.open(LikedusersComponent, dialogConfig)
  }

  openSharedUsers(keechId){
    let dialogConfig= new MatDialogConfig();
    dialogConfig.width = '500px';
    dialogConfig.height = '500px';

    dialogConfig.data = {
      keechId: keechId
    }

    this.likedSharedUsersDialog.open(SharedusersComponent, dialogConfig)
  }

}
