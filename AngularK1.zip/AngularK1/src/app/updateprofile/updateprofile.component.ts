import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ProfileupdateService } from '../services/profileupdate.service';
import { Router } from '@angular/router';
import { HttpEventType } from '@angular/common/http';
import { BASE_URL } from '../shared/constants';


@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {

  message='';
  textColor;
  showSpinner=false;
  fullname='';
  uname = localStorage.getItem('ssid');
  avatar;
  avatarurl;
  updatedAvatarUrl;
  baseUrl=BASE_URL;
  updatedAvatar=false;
  profileForm = new FormGroup({
    firstname: new FormControl(''),
    lastname: new FormControl('')
  }
  )
  newAvatar;
  uploadProgress;

  constructor(private profUpdService: ProfileupdateService,
    private _router: Router) { }

  ngOnInit(): void {
    this.profUpdService.getUserProfile().subscribe(
      res => {
       
        this.profileForm.setValue({'firstname':res.firstname, 'lastname': res.lastname}) 
        this.fullname = this.profileForm.get('firstname').value +' '+ this.profileForm.get('lastname').value
        this.avatarurl=this.baseUrl+res.avatarurl;
        
      }
    )

  }

  saveProfile(){
    this.message='';
    this.textColor='black';
    this.showSpinner=true;
    
    this.profUpdService.updateProfile(this.profileForm.value).subscribe(
      res=> { 
        
        this.showSpinner=false;
        this.message = "Updated Profile"
        this.fullname = this.profileForm.get('firstname').value +' '+ this.profileForm.get('lastname').value
        
      },
      err=> {
        console.log(err);
        this.showSpinner=false;
        this.textColor='red';
        this.message="Error occured while Updating. Please try later"
      }
    )

  }

  cancelProfileChange(){
    this._router.navigate(['/home']);
  }

  selectAvatar(event) {
    if(event.target.files.length>0) {
      var reader = new FileReader()
      this.newAvatar=reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => { 
        this.avatarurl = reader.result; 
      }
      this.avatar = event.target.files[0];
      
    }
  }

  saveAvatar(){
    this.updatedAvatar=false;
    
    const formData = new FormData();
    formData.append('avatar',this.avatar)
    this.profUpdService.updateAvatar(formData).subscribe(
      event => {
        
        if(event.type == HttpEventType.UploadProgress) {
         
          this.uploadProgress = Math.round(event.loaded/event.total*100);
        }
      
      
     
      },
      err => console.log(err)
    )
  }




}
