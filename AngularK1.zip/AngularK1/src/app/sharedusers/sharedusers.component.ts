import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BASE_URL } from '../shared/constants';
import { KeechdetailService } from '../services/keechdetail.service';

@Component({
  selector: 'app-sharedusers',
  templateUrl: './sharedusers.component.html',
  styleUrls: ['./sharedusers.component.css']
})
export class SharedusersComponent implements OnInit {

  keechId;
  sharedUsers;
  baseUrl=BASE_URL;

  constructor(private kdService: KeechdetailService,
    @Inject(MAT_DIALOG_DATA) data) {
      this.keechId=data.keechId
     }

  ngOnInit(): void {
    

    this.kdService.getSharedUsers(this.keechId)
    .subscribe(
      res => this.sharedUsers=res,
      err => console.log(err)
    )
  }

}
