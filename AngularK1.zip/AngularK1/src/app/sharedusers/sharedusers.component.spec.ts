import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedusersComponent } from './sharedusers.component';

describe('SharedusersComponent', () => {
  let component: SharedusersComponent;
  let fixture: ComponentFixture<SharedusersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharedusersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
