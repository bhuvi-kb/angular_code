import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BASE_URL } from '../shared/constants';
import { FollowService } from '../services/follow.service';

@Component({
  selector: 'app-userfollowing',
  templateUrl: './userfollowing.component.html',
  styleUrls: ['./userfollowing.component.css']
})
export class UserfollowingComponent implements OnInit {

  userid;
  followers;
  baseUrl=BASE_URL;
  following;

  constructor(private fs: FollowService,
    @Inject(MAT_DIALOG_DATA) data) {
      this.userid=data.userid
     }

  ngOnInit(): void {
   

    this.fs.getFollowing(this.userid).subscribe(
      res=> {
        
        this.following=res;
      },
      err=> console.log(err)
    );


  }

  

}
