import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSidenavModule } from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDialogModule } from '@angular/material/dialog';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatBadgeModule} from '@angular/material/badge';
import { MatMenuModule } from '@angular/material/menu';

const MaterialComponents = [MatButtonModule, MatToolbarModule, MatInputModule,MatCardModule,
  MatProgressSpinnerModule, MatSidenavModule, MatIconModule, MatListModule, MatProgressBarModule,
  MatDialogModule, MatAutocompleteModule, MatBadgeModule, MatMenuModule]

@NgModule({
  declarations: [],
  imports: [
    MatButtonModule, MatToolbarModule, MatInputModule,MatCardModule,MatProgressSpinnerModule, MatSidenavModule,
    MatIconModule, MatListModule, MatProgressBarModule, MatDialogModule, MatAutocompleteModule, MatBadgeModule,
    MatMenuModule
  ],
  exports: [MatButtonModule, MatToolbarModule, MatInputModule, MatCardModule,
     MatProgressSpinnerModule, MatSidenavModule, MatIconModule, MatListModule, MatProgressBarModule,
     MatDialogModule, MatAutocompleteModule, MatBadgeModule, MatMenuModule]
})
export class MaterialModule { }
