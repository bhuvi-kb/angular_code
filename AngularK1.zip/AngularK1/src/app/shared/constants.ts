//old // export const BASE_URL = "https://frugalserver-cc-uc-1-frugal.container-crush-01-4044f3a4e314f4bcb433696c70d13be9-0000.che01.containers.appdomain.cloud/";
//export const BASE_URL = "http://localhost:3000/"
export const BASE_URL = "https://frugalserver-cc-uc-1-frugal.container-crush-01-4044f3a4e314f4bcb433696c70d13be9-0000.che01.containers.appdomain.cloud/"