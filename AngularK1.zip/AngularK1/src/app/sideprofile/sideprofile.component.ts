import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sideprofile',
  templateUrl: './sideprofile.component.html',
  styleUrls: ['./sideprofile.component.css']
})
export class SideprofileComponent implements OnInit {

  uname = localStorage.getItem('ssid');
  
  constructor(private loginService:LoginService, private _router:Router) { }

  ngOnInit(): void {
  }

  logout(){
    this.loginService.logOut();
    this._router.navigate(['/login'])
  }

}
