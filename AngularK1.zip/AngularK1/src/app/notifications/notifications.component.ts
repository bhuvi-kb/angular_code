import { Component, OnInit } from '@angular/core';
import { HomeService } from '../services/home.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  allNotifications;
  constructor(private homeService: HomeService) { }

  ngOnInit(): void {
    this.homeService.getNotifications().subscribe(
      res=>
      { 
        this.allNotifications=res;
        this.allNotifications.sort((a,b)=> {
          if(a.createdAt < b.createdAt) return 1;
          else if (a.createdAt > b.createdAt) return -1;
          else return 0
        });
        
        console.log(res);
        this.homeService.updateNotifications().subscribe(
          res=> {
           // console.log(res)
          },
          err=> {
            console.log(err)
          }
        )
      },
      err=> console.log(err)
    )
  }
  
}
