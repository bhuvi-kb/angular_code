export class LoginResponse {
    errCode: number;
    message: string
}