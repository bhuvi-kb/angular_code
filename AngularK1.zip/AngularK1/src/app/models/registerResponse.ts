export class RegisterResponse {
    errCode: number;
    message: string
}