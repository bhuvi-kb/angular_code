export class Keech {
    _id: string;
    author: string;
    keechBody: string;
    likes: number; 
    shares: number; 
    comments: string[];
    date: Date
}