export class regUser {
    username: string;
    password: string;
    confirmPasswor: string
}