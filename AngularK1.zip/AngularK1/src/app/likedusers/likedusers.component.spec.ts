import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LikedusersComponent } from './likedusers.component';

describe('LikedusersComponent', () => {
  let component: LikedusersComponent;
  let fixture: ComponentFixture<LikedusersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LikedusersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LikedusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
