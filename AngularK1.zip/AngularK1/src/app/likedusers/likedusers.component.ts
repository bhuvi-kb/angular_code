import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BASE_URL } from '../shared/constants';
import { KeechdetailService } from '../services/keechdetail.service';

@Component({
  selector: 'app-likedusers',
  templateUrl: './likedusers.component.html',
  styleUrls: ['./likedusers.component.css']
})
export class LikedusersComponent implements OnInit {

  keechId;
  likedUsers;
  baseUrl=BASE_URL;

  constructor(private kdService: KeechdetailService,
    @Inject(MAT_DIALOG_DATA) data) {
      this.keechId=data.keechId
     }

  ngOnInit(): void {

    this.kdService.getLikedUsers(this.keechId)
    .subscribe(
      res => this.likedUsers=res,
      err => console.log(err)
    )
  }

}
