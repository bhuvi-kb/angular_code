import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { RegisterResponse } from '../models/registerResponse';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  serverUrl = BASE_URL+'register';

  constructor(private http: HttpClient) { }

  registerUser(user) {
    return this.http.post<RegisterResponse>(this.serverUrl, JSON.stringify(user),
     { headers: new HttpHeaders({'Content-Type': 'application/json'})}
      //{"username":"user@email.com", "password":"password", "confirmPassword":"password"}
      )
  }

}
