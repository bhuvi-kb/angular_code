import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class SuggestionsService {

  suggestionUrl = BASE_URL+"suggestions";

  constructor(private _http:HttpClient) { }

  getSuggestions() {
    return this._http.get<any>(this.suggestionUrl,
      { headers: new HttpHeaders({'Content-Type': 'application/json'}), observe: "response"})
  }

}
