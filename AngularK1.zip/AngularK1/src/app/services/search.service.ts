import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, empty} from 'rxjs';
import { map } from 'rxjs/Operators';
import { BASE_URL } from '../shared/constants';



@Injectable({
  providedIn: 'root'
})
export class SearchService {

  public baseUrl = BASE_URL+'searchpeople';
  public searchResults:any;

  constructor(private _http: HttpClient) { }

  public searchEntries(term):Observable<any>{
    if(term === '') {
      
      return empty();
    }
    else {
      let params = {q: term};
      
      return this._http.get(this.baseUrl, {params}).pipe(
        map(response => {
          
          return this.searchResults=response;
        })
      )
    }
  }

  public _searchEntries(term){
    return this.searchEntries(term);  

  }
}
