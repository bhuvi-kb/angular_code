import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Keech } from '../models/keech';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class KeechService {

  url =BASE_URL+"postKeech";
  getKeechUrl=BASE_URL+"user";
  baseUrl=BASE_URL;

  constructor(private http: HttpClient) { }

  postKeech(keech) {
    return this.http.post<any>(this.url, keech)
  }

  getKeeches(userid) {

    return this.http.get<any>(this.getKeechUrl+"/"+userid)
  }

  deleteKeech(keechId) {
    return this.http.post(this.baseUrl+'deletekeech', {keechId} )
  }

}
