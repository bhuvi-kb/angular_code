import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class ProfileupdateService {

  profileUpdateUrl = BASE_URL+"updateprofile";
  userProfileUrl = BASE_URL+"user/";
  addfollowingUrl = this.profileUpdateUrl+'/addfollowing';
  profileImageUrl = BASE_URL+"profile_images";
  unfollowUrl = this.profileUpdateUrl+'/unfollow';

  constructor(private _http:HttpClient) { }

  updateProfile(formData) {
   return this._http.post<any>(this.profileUpdateUrl,formData);
  }



  getUserProfile(userid?) {
    if(userid){
      return this._http.get<any>(this.userProfileUrl+userid+'/profile')
    }
    else {
      return this._http.get<any>(this.userProfileUrl)
    }
  }

  addFollowing(following) {
    return this._http.post(this.addfollowingUrl, {following})
  }

  unfollow(unfollowed) {
    return this._http.post(this.unfollowUrl, {unfollowed})
  }

  updateAvatar(formData) {
    return this._http.post<any>(this.profileImageUrl, formData, {
      reportProgress: true, observe:'events'
    })
  }

}
