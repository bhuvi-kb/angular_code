import { TestBed } from '@angular/core/testing';

import { KeechService } from './keech.service';

describe('KeechService', () => {
  let service: KeechService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeechService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
