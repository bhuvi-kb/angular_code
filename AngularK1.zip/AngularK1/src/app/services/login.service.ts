import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//import { LoginResponse } from '../models/loginResponse';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  /*
  loginUrl = "http://localhost:3000/login";
  */
  loginUrl = BASE_URL + "login";
  

  constructor(private http: HttpClient) { }

  loginUser(user) {
  
    return this.http.post<any>(this.loginUrl, JSON.stringify(user),
    { headers: new HttpHeaders({'Content-Type': 'application/json'}), observe: "response"}
    //{"username":"user@email.com", "password":"password", "confirmPassword":"password"}
    )

   }

   loggedIn() {
     return !!localStorage.getItem('token')
   }

   logOut() {
     localStorage.removeItem('token');
   }

   getToken(){
     return localStorage.getItem('token')
   }


}
