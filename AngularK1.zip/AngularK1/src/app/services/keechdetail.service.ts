import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class KeechdetailService {

  constructor(private _http: HttpClient) { }

  getPostDetail(id){
    return this._http.get(BASE_URL+'post/'+id)
  }

  getReplies(id){
    return this._http.get(BASE_URL+'post/'+id+'/replies')
  }

  getLikedUsers(id){
    return this._http.get(BASE_URL+'post/'+id+'/likes')
  }

  getSharedUsers(id){
    return this._http.get(BASE_URL+'post/'+id+'/shares')
  }

}
