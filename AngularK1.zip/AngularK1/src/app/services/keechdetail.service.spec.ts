import { TestBed } from '@angular/core/testing';

import { KeechdetailService } from './keechdetail.service';

describe('KeechdetailService', () => {
  let service: KeechdetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeechdetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
