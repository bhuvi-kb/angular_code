import { TestBed } from '@angular/core/testing';

import { LikeshareService } from './likeshare.service';

describe('LikeshareService', () => {
  let service: LikeshareService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LikeshareService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
