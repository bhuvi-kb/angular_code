import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class FollowService {

  followServiceUrl= BASE_URL;

  constructor(private _http: HttpClient) { }

  getFollowers(userid?){
    
    if(userid){
      //console.log(this.followServiceUrl+'user/'+userid+'/followers');
      return this._http.get<any>(this.followServiceUrl+'user/'+userid+'/followers')
    }
    else {
      return this._http.get<any>(this.followServiceUrl+'followers')
    }

}

getFollowing(userid?){
    
  if(userid){
    //console.log(this.followServiceUrl+'user/'+userid+'/following');
    return this._http.get<any>(this.followServiceUrl+'user/'+userid+'/following')
  }
  else {
    return this._http.get<any>(this.followServiceUrl+'following')
  }

}

}
