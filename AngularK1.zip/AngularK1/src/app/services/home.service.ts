import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { of } from 'rxjs';
//import { Keech } from '../models/keech';
import { BASE_URL } from '../shared/constants';


@Injectable({
  providedIn: 'root'
})
export class HomeService {


  /*
  homeUrl = "http://localhost:3000/postKeech";
  */
 baseUrl=BASE_URL;
 homeUrl = BASE_URL +"postKeech";


  constructor(private _http: HttpClient ) { }

  onInit() {
   
  }

  getHomeData() {
    //console.log(this.homeUrl);
    return this._http.get<any>(this.homeUrl)
    
  }

  getNotifications() {
    return this._http.get(this.baseUrl+'notifications');
    
  }

  updateNotifications(){
    return this._http.post(this.baseUrl+'notifications','id');
  }

}
