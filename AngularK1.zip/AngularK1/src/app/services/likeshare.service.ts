import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BASE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class LikeshareService {

  

  constructor(private _http: HttpClient) { }

  addLike(keechId) {
    return this._http.post(BASE_URL+'likekeech', {keechId})
  }

  removeLike(keechId) {
    return this._http.post(BASE_URL+'unlikekeech', {keechId})
  }

  addShare(keechId) {
    return this._http.post(BASE_URL+'sharekeech', {keechId})
  }

  removeShare(keechId) {
    return this._http.post(BASE_URL+'unsharekeech', {keechId})
  }

}


