import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FollowService } from '../services/follow.service';
import { BASE_URL } from '../shared/constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-following',
  templateUrl: './following.component.html',
  styleUrls: ['./following.component.css']
})
export class FollowingComponent implements OnInit {

  
  baseUrl=BASE_URL;
  following;

  constructor(private fs: FollowService) { }

  ngOnInit(): void {
    this.fs.getFollowing().subscribe(
      res=> {
        //console.log(res),
        this.following=res;
      },
      err=> console.log(err)
    );
  }

  


}
