import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MaterialModule } from './Materials/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth.guard';
import { LoginService } from './services/login.service';
import { RegisterService } from './services/register.service';
import { TokeninterceptorService } from './services/tokeninterceptor.service';
import { SideprofileComponent } from './sideprofile/sideprofile.component';
import { UserdetailComponent } from './userdetail/userdetail.component';
import { DateAgoPipe } from './pipes/date-ago.pipe';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { FollowersComponent } from './followers/followers.component';
import { FollowingComponent } from './following/following.component';
import { UserfollowingComponent } from './userfollowing/userfollowing.component';
import { UserfollowersComponent } from './userfollowers/userfollowers.component';
import { SearchComponent } from './search/search.component';
import { KeechdetailComponent } from './keechdetail/keechdetail.component';
import { LikedusersComponent } from './likedusers/likedusers.component';
import { SharedusersComponent } from './sharedusers/sharedusers.component';
import { NotificationsComponent } from './notifications/notifications.component';



@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    SideprofileComponent,
    UserdetailComponent,
    DateAgoPipe,
    UpdateprofileComponent,
    FollowersComponent,
    FollowingComponent,
    UserfollowingComponent,
    UserfollowersComponent,
    SearchComponent,
    KeechdetailComponent,
    LikedusersComponent,
    SharedusersComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    HttpClientModule
  ],
  providers: [AuthGuard, LoginService, RegisterService,
    {
      provide: HTTP_INTERCEPTORS, useClass: TokeninterceptorService, multi: true
    }
  ],
  entryComponents: [
    FollowersComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
