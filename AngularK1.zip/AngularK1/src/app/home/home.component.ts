import { Component, OnInit } from '@angular/core';
import { HomeService } from '../services/home.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Keech } from '../models/keech';
import { KeechService } from '../services/keech.service';
import { SuggestionsService } from '../services/suggestions.service';
import { LoginService } from '../services/login.service';
import { ProfileupdateService } from '../services/profileupdate.service';
import { BASE_URL } from '../shared/constants';
import { FollowService } from '../services/follow.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FollowersComponent } from '../followers/followers.component';
import { FollowingComponent } from '../following/following.component';
import { Subject, throwError, of} from 'rxjs';
import { map, debounceTime, distinctUntilChanged, switchMap, catchError, retryWhen, retry } from 'rxjs/operators';
import { SearchService } from '../services/search.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LikeshareService } from '../services/likeshare.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  keechData =[];
  sorted =[];

  keechText={keechBody:''};
  postedKeech={avatarurl:''};
  token = localStorage.getItem('token');
  //uname = localStorage.getItem('ssid');
  uname='';
  disablePostText=false;
  fullname='';
  numfollowers;
  numfollowing;
  baseUrl=BASE_URL;
  avatarurl;
  suggestions;
  followers=[];
  loggedUserId;


  public loading:boolean;
  public searchTerm=new Subject<string>();
  public searchResults:any;
  public paginationElements:any;
  public errorMessage;

  private notificactions=[];
  public numNotifications;

  
  public searchForm = new FormGroup({
    search: new FormControl("")
  })
 

  constructor(private homeService: HomeService,
    private _router: Router, private keechService: KeechService,
    private suggestionService: SuggestionsService,
    private loginService: LoginService,
    private profService: ProfileupdateService,
    public followersDialog: MatDialog,
    private searchService: SearchService,
    private likesShareService: LikeshareService,
     ) { }

  ngOnInit(): void {

    this.homeService.getNotifications().subscribe(
      res => 
      {
        this.notificactions.push(res);
        this.numNotifications=this.notificactions[0].filter(a=>a.viewed==false).length
        
        
      },
      err => console.log(err)


    )


    this.profService.getUserProfile().subscribe(
      res=> {
        //console.log("user profile from home!", res)
        this.uname=res.username;
        if(res.firstname  || res.lastname )
        {
          this.fullname=res.firstname + ' ' + res.lastname
        };
        this.numfollowers=res.numfollowers;
        this.numfollowing=res.numfollowing;
        this.avatarurl=this.baseUrl+res.avatarurl;
        this.loggedUserId=res.userid;
        console.log("user id in prof",this.loggedUserId)
      }
    );


    this.homeService.getHomeData()
    .subscribe(
      
      response => {
        //console.log(response)
        this.keechData=response;
        this.keechData.sort((a,b)=> {
          if(a.date < b.date) return 1;
          else if (a.date > b.date) return -1;
          else return 0
        })
        
      },
      err => {
        //console.log("error happened.")
        if (err instanceof HttpErrorResponse ) {
          if (err.status == 401) {
           // console.log("rerouting to login");
            
            this._router.navigate(['/login'])
          }
        }
      }

    )

    

    this.suggestionService.getSuggestions().subscribe(
      response => {
        //console.log(response.body);
        this.suggestions=response.body;

      },
      err => console.log(err)
    )

      this.search();
 
  }

  postKeech(keech) {
    //console.log(JSON.stringify(keech));
    this.disablePostText=true;
    this.keechService.postKeech(keech).subscribe(
      (res)=> {
        //console.log(res);
        this.postedKeech=res;
        // console.log(res.authorId)
        // //console.log(this.avatarurl);
        // //this.postedKeech.avatarurl=this.avatarurl;
       
        this.keechText.keechBody='';
        this.keechData.unshift(this.postedKeech);
        this.disablePostText=false;
        
        
      },
      (err)=> {
        console.log(err);
        this.disablePostText=false;
      }
    )
  }

  logout(){
    this.loginService.logOut();
    this._router.navigate(['/login'])
  }

  openFollowers(){
    this.followersDialog.open(FollowersComponent, {width: '500px',height:'500px' })
  }

  openFollowing(){
    this.followersDialog.open(FollowingComponent, {width: '500px',height:'500px' })
  }

  public search(){
    this.searchTerm.pipe(
      map((e:any)=> {
        //console.log(e.target.value);
        return e.target.value;

      }),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(term=>{
        this.loading=true;
        //console.log("inside switchmap")
        return this.searchService._searchEntries(term)
      }),
      catchError((e)=>{
        //console.log('error happened')
        this.loading=false;
        this.errorMessage=e.errorMessage;
        return throwError(e)
      })
    ).subscribe(v=>{
      //console.log("inside sub")
      this.loading=true;
      this.searchResults=v;
      this.suggestions=v;
      this.paginationElements=this.searchResults;
    })
  }


 
  toggleLikeKeech(keech){

    if (!keech.isLiked) {

      this.likesShareService.addLike(keech._id).subscribe(
        res => {
          //console.log(res);
          keech.isLiked = !keech.isLiked
          keech.likes ++
        },
        err => {
          console.log(err)
        }
      );


    }
    else {

      this.likesShareService.removeLike(keech._id).subscribe(
        res => {
          //console.log(res);
          keech.isLiked = !keech.isLiked
          keech.likes --
        },
        err => console.log(err)
      );
 

    }


  }


  toggleShareKeech(keech){

    if (!keech.isShared) {

      this.likesShareService.addShare(keech._id).subscribe(
        res => {
         // console.log(res);
          keech.isShared = !keech.isShared
          keech.shares ++
        },
        err => console.log(err)
      );


    }
    else {

      this.likesShareService.removeShare(keech._id).subscribe(
        res => {
          //console.log(res);
          keech.isShared = !keech.isShared
          keech.shares --
        },
        err => console.log(err)
      );
 

    }


  }


  deleteKeech(keechId) {
    this.keechService.deleteKeech(keechId).subscribe(
      res=> {
        //console.log(res);
        this.keechData = this.keechData.filter(e=> e._id != keechId);
      },
      err=> console.log(err)
    )
  }

}
