import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators }  from '@angular/forms';
import { Subject, throwError, of} from 'rxjs';
import { map, debounceTime, distinctUntilChanged, switchMap, catchError, retryWhen, retry } from 'rxjs/operators';
import { SearchService } from '../services/search.service';
import { BASE_URL } from '../shared/constants';



@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  public loading:boolean;
  public searchTerm=new Subject<string>();
  public searchResults:any;
  public paginationElements:any;
  public errorMessage;
  baseUrl=BASE_URL;

  public searchForm = new FormGroup({
    search: new FormControl("",Validators.required)
  })

  constructor(private searchService: SearchService) { }

  ngOnInit(): void {
    this.search();
  }


  public search(){
    this.searchTerm.pipe(
      map((e:any)=> {
        //console.log(e.target.value);
        return e.target.value;

      }),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(term=>{
        this.loading=true;
        //console.log("inside switchmap")
        return this.searchService._searchEntries(term)
      }),
      catchError((e)=>{
        //console.log('error happened')
        this.loading=false;
        this.errorMessage=e.errorMessage;
        return throwError(e)
      })
    ).subscribe(v=>{
      //console.log("inside sub")
      this.loading=true;
      this.searchResults=v;
      this.paginationElements=this.searchResults
    })
  }

}
