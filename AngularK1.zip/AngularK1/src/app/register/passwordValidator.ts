import { AbstractControl } from '@angular/forms';


export function PasswordValidator(control: AbstractControl):{[key: string]: boolean } | null {
    const password = control.get('password');
    const cPassword = control.get('confirmPassword');

    if(password.pristine || cPassword.pristine) {
        return null
    }
    else {
    return password && cPassword && password.value !== cPassword.value ?
    { 'misMatch': true}: null
    }
}