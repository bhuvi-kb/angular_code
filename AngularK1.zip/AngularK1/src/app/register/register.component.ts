import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { PasswordValidator } from './passwordValidator';
import { RegisterService } from '../services/register.service';
import { Router } from '@angular/router';
//import { RegisterResponse } from '../models/registerResponse';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm = this.fb.group({
    email: ['', Validators.required],
    username: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(8)]],
    confirmPassword:['',[Validators.required, Validators.minLength(8)]]
  },{validator: PasswordValidator});

  //regResponse: RegisterResponse;
  regSuccess = false;
  message = '';
  showSpinner=false;


  constructor(private fb: FormBuilder, private registerService: RegisterService) { }

  ngOnInit(): void {
  }

  register(){

    this.showSpinner=true;
    this.message= '';
    //this.user = JSON.stringify(this.registerForm.value);
    //console.log(user);

    
    this.registerService.registerUser(this.registerForm.value).subscribe(
      (response) => {
        
        this.regSuccess = false;
        //console.log(JSON.stringify(response));
        if(response.errCode == 0) {
          this.regSuccess = true;
          this.showSpinner=false;
          
        }
        else {
          this.message=response.message
          this.showSpinner=false;
        }
      },
      err => {console.log(err);
        this.message="Oops! Some error happened. Please try again!"
        this.showSpinner=false;
      }
    )

  }

  resetForm(){
    this.registerForm.reset();
  }

}
