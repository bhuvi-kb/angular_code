import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BASE_URL } from '../shared/constants';
import { FollowService } from '../services/follow.service';


@Component({
  selector: 'app-userfollowers',
  templateUrl: './userfollowers.component.html',
  styleUrls: ['./userfollowers.component.css']
})
export class UserfollowersComponent implements OnInit {

  userid;
  followers;
  baseUrl=BASE_URL

  constructor(private fs: FollowService,
    @Inject(MAT_DIALOG_DATA) data) {
    this.userid = data.userid
   }

  ngOnInit(): void {

    this.fs.getFollowers(this.userid).subscribe(
      res=> {
        
        this.followers=res;
      },
      err=> console.log(err)
    );

  }

}
