import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserfollowersComponent } from './userfollowers.component';

describe('UserfollowersComponent', () => {
  let component: UserfollowersComponent;
  let fixture: ComponentFixture<UserfollowersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserfollowersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserfollowersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
