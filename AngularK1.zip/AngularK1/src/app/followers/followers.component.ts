import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FollowService } from '../services/follow.service';
import { BASE_URL } from '../shared/constants';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {

  baseUrl=BASE_URL;
  followers;

  constructor(private fs: FollowService) { }

  ngOnInit(): void {
    this.fs.getFollowers().subscribe(
      res=> {
        //console.log(res),
        this.followers=res;
      },
      err=> console.log(err)
    );

  }


}
