import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup(
    {
      username: new FormControl(''),
      password: new FormControl('')
    }
  )

  loginSuccess;
  message;
  showSpinner=false;

  constructor(private loginService: LoginService, private _router: Router) { }

  ngOnInit(): void {
  }

  loginUser(){

    //this.user = JSON.stringify(this.registerForm.value);
    //console.log(user);
    //console.log(this.loginForm.value)
    this.message='';
    this.showSpinner=true;

    this.loginService.loginUser(this.loginForm.value).subscribe(
      (response) => {
        //console.log(response.body);
        localStorage.setItem('token',response.body.token);
        localStorage.setItem('ssid', response.body.ssid);
        this._router.navigate(['/home']);
      },
      err => {
        console.log(err);
        //console.log(err)
        this.message="Oops! Some error happened. Please try again!"
        this.showSpinner=false;
      }
    )

  }

  resetLoginForm(){
    this.loginForm.reset();
    this.message='';
    this.showSpinner=false;

  }
  
  

}
